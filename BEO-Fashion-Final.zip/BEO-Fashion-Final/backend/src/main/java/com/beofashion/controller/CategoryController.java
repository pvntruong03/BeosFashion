package com.beofashion.controller;

import com.beofashion.dto.ApiResponse;
import com.beofashion.dto.CategoryDto;
import com.beofashion.entity.Gender;
import com.beofashion.service.CategoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categories")
@RequiredArgsConstructor
@Tag(name = "Categories", description = "Hierarchical Category browsing")
public class CategoryController {

    private final CategoryService categoryService;

    @GetMapping
    @Operation(summary = "Get all root categories with subcategory trees")
    public ResponseEntity<ApiResponse<List<CategoryDto>>> getCategories() {
        return ResponseEntity.ok(ApiResponse.ok(categoryService.getAllRootCategories()));
    }

    @GetMapping("/gender/{gender}")
    @Operation(summary = "Get categories by gender (MEN, WOMEN, UNISEX)")
    public ResponseEntity<ApiResponse<List<CategoryDto>>> getCategoriesByGender(@PathVariable Gender gender) {
        return ResponseEntity.ok(ApiResponse.ok(categoryService.getCategoriesByGender(gender)));
    }

    @GetMapping("/{slug}")
    @Operation(summary = "Get category by slug")
    public ResponseEntity<ApiResponse<CategoryDto>> getCategoryBySlug(@PathVariable String slug) {
        return ResponseEntity.ok(ApiResponse.ok(categoryService.getCategoryBySlug(slug)));
    }
}
