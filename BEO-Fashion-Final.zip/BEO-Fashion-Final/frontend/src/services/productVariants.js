export const isAdultVariant = (variant) => variant.active !== false &&
  !/^(?:[5-9]0|1[0-6]0)$/.test(String(variant.size).trim());

export const sortSizes = (sizes) => {
  const order = ['FREE', 'XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL', '4XL'];
  return [...new Set(sizes)].sort((a, b) => {
    const left = order.indexOf(a), right = order.indexOf(b);
    return (left < 0 ? 100 : left) - (right < 0 ? 100 : right) || String(a).localeCompare(String(b), undefined, { numeric: true });
  });
};
