import { describe, expect, it } from 'vitest';
import { isAdultVariant, sortSizes } from './productVariants';

describe('product variant rules', () => {
  it('hides inactive and legacy numeric variants', () => {
    expect(isAdultVariant({ size: 'M', active: true })).toBe(true);
    expect(isAdultVariant({ size: '100', active: true })).toBe(false);
    expect(isAdultVariant({ size: 'L', active: false })).toBe(false);
  });

  it('sorts adult apparel sizes in shopping order without duplicates', () => {
    expect(sortSizes(['XL', 'S', 'M', 'S', 'FREE'])).toEqual(['FREE', 'S', 'M', 'XL']);
  });
});
